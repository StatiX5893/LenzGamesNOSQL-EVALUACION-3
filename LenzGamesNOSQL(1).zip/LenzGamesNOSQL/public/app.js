const API = '/api/videojuegos';
const $ = (id) => document.getElementById(id);
let juegosActuales = [];
let pedidosActuales = [];

// Evita que un texto con < > rompa la página
function escapar(texto) {
  const div = document.createElement('div');
  div.textContent = texto ?? '';
  return div.innerHTML;
}

// Formato de pesos chilenos: 32000 → $32.000
const pesos = (n) => '$' + Number(n).toLocaleString('es-CL');
const fecha = (f) => new Date(f).toLocaleString('es-CL', { dateStyle: 'short', timeStyle: 'short' });

// Muestra un aviso verde (éxito) o rojo (error) por 3 segundos
function mostrarMensaje(texto, tipo = 'success') {
  const m = $('mensaje');
  m.className = `alert alert-${tipo}`;
  m.textContent = texto;
  clearTimeout(mostrarMensaje.t);
  mostrarMensaje.t = setTimeout(() => m.classList.add('d-none'), 3000);
}

// ================== SESIÓN ==================

const leerToken = () => { try { return sessionStorage.getItem('lenz_token'); } catch { return null; } };
const guardarToken = (t) => { try { t ? sessionStorage.setItem('lenz_token', t) : sessionStorage.removeItem('lenz_token'); } catch {} };

// fetch que envía el token. Si la sesión venció, vuelve al login.
async function api(url, opciones = {}) {
  const res = await fetch(url, {
    ...opciones,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${leerToken()}`, ...opciones.headers }
  });
  if (res.status === 401) {
    mostrarLogin();
    throw new Error('Sesión vencida');
  }
  return res;
}

function mostrarLogin() {
  guardarToken(null);
  $('vistaLogin').classList.remove('d-none');
  $('vistaPanel').classList.add('d-none');
  $('btnSalir').classList.add('d-none');
}

function mostrarPanel() {
  $('vistaLogin').classList.add('d-none');
  $('vistaPanel').classList.remove('d-none');
  $('btnSalir').classList.remove('d-none');
  cargarPedidos();
  cargarJuegos();
}

$('formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('errorLogin').textContent = '';
  const res = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: $('password').value })
  });
  const r = await res.json();
  if (!res.ok) return ($('errorLogin').textContent = r.error);
  guardarToken(r.token);
  $('formLogin').reset();
  mostrarPanel();
});

$('btnSalir').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch {}
  mostrarLogin();
});

// ================== PEDIDOS ==================

const ESTADOS = ['Pendiente', 'Pagado', 'Enviado', 'Entregado', 'Cancelado'];

async function cargarPedidos() {
  const params = new URLSearchParams();
  if ($('filtroEstado').value) params.set('estado', $('filtroEstado').value);
  const res = await api(`/api/pedidos?${params}`);
  pedidosActuales = await res.json();

  $('tablaPedidos').innerHTML = pedidosActuales.map(p => {
    const unidades = p.items.reduce((s, it) => s + it.cantidad, 0);
    const cancelado = p.estado === 'Cancelado';
    return `
      <tr>
        <td class="fw-semibold">${escapar(p.codigo)}</td>
        <td class="small">${fecha(p.createdAt)}</td>
        <td>${escapar(p.cliente.nombre)}<div class="text-secondary small">${escapar(p.cliente.email)}</div></td>
        <td>${unidades} ${unidades === 1 ? 'unidad' : 'unidades'}</td>
        <td>${pesos(p.total)}</td>
        <td>
          <select class="form-select form-select-sm select-estado estado-${escapar(p.estado)}" data-id="${p._id}" ${cancelado ? 'disabled' : ''}>
            ${ESTADOS.map(e => `<option ${e === p.estado ? 'selected' : ''}>${e}</option>`).join('')}
          </select>
        </td>
        <td class="text-end"><button class="btn btn-sm btn-outline-info" data-ver="${p._id}">Ver</button></td>
      </tr>`;
  }).join('') || '<tr><td colspan="7" class="text-secondary">No hay pedidos todavía</td></tr>';

  cargarResumenVentas();
}

// Cambiar el estado de un pedido
$('tablaPedidos').addEventListener('change', async (e) => {
  const select = e.target.closest('.select-estado');
  if (!select) return;
  const pedido = pedidosActuales.find(p => p._id === select.dataset.id);
  const estado = select.value;

  if (estado === 'Cancelado' && !confirm(`¿Cancelar el pedido ${pedido.codigo}? El stock se devolverá y no se podrá deshacer.`)) {
    select.value = pedido.estado;
    return;
  }

  const res = await api(`/api/pedidos/${pedido._id}/estado`, { method: 'PATCH', body: JSON.stringify({ estado }) });
  const r = await res.json();
  if (!res.ok) {
    select.value = pedido.estado;
    return mostrarMensaje(r.error, 'danger');
  }
  mostrarMensaje(`Pedido ${r.codigo}: ${r.estado}`);
  cargarPedidos();
  if (estado === 'Cancelado') cargarJuegos();   // el stock cambió
});

// Ver el detalle de un pedido
$('tablaPedidos').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-ver]');
  if (!btn) return;
  const p = pedidosActuales.find(x => x._id === btn.dataset.ver);

  $('pedidoTitulo').textContent = `Pedido ${p.codigo}`;
  $('pedidoCuerpo').innerHTML = `
    <p class="mb-1"><span class="badge estado-${escapar(p.estado)}">${escapar(p.estado)}</span>
      <span class="text-secondary small ms-2">${fecha(p.createdAt)}</span></p>
    <h6 class="seccion mt-3">Cliente</h6>
    <p class="small mb-0">${escapar(p.cliente.nombre)}</p>
    <p class="small mb-0">${escapar(p.cliente.email)}${p.cliente.telefono ? ' · ' + escapar(p.cliente.telefono) : ''}</p>
    <p class="small">${escapar(p.cliente.direccion)}</p>
    <h6 class="seccion">Productos</h6>
    ${p.items.map(it => `
      <div class="d-flex align-items-center gap-2 mb-2">
        ${it.imagen ? `<img src="${escapar(it.imagen)}" alt="" class="mini-portada">` : ''}
        <span class="flex-grow-1 small">${it.cantidad} × ${escapar(it.nombre)} <span class="text-secondary">(${pesos(it.precio)} c/u)</span></span>
        <span class="small">${pesos(it.precio * it.cantidad)}</span>
      </div>`).join('')}
    <div class="d-flex justify-content-between fw-bold border-top pt-2 mt-2"><span>Total</span><span>${pesos(p.total)}</span></div>`;
  bootstrap.Modal.getOrCreateInstance($('modalPedido')).show();
});

// Tarjetas de resumen (agregación sobre la colección pedidos)
async function cargarResumenVentas() {
  const res = await api('/api/reportes/ventas');
  const r = await res.json();
  const top = r.masVendidos[0];
  $('resumenVentas').innerHTML = `
    <div class="kpi"><strong>${pesos(r.ventas)}</strong>Ventas (sin cancelados)</div>
    <div class="kpi"><strong>${r.pedidos}</strong>Pedidos válidos</div>
    <div class="kpi"><strong>${r.porEstado.Pendiente || 0}</strong>Pendientes por revisar</div>
    <div class="kpi"><strong>${top ? escapar(top._id) : '—'}</strong>${top ? `Más vendido (${top.unidades} u.)` : 'Más vendido'}</div>`;
}

$('filtroEstado').addEventListener('change', cargarPedidos);
$('btnRecargar').addEventListener('click', cargarPedidos);

// ================== VIDEOJUEGOS ==================

// READ: carga la tabla con los filtros
async function cargarJuegos() {
  const params = new URLSearchParams();
  if ($('buscar').value) params.set('buscar', $('buscar').value);
  if ($('filtroPlataforma').value) params.set('plataforma', $('filtroPlataforma').value);
  if ($('stockBajo').checked) params.set('stockBajo', 'true');

  const res = await fetch(`${API}?${params}`);
  juegosActuales = await res.json();

  $('tablaJuegos').innerHTML = juegosActuales.map(j => `
    <tr>
      <td>
        ${j.imagen ? `<img src="${escapar(j.imagen)}" alt="" class="mini-portada">` : ''}
        ${escapar(j.nombre)}
      </td>
      <td>${escapar(j.categoria)}</td>
      <td>${j.plataformas.map(p => `<span class="badge badge-plat">${escapar(p)}</span>`).join('')}</td>
      <td>${pesos(j.precio)}</td>
      <td class="${j.stock < j.stock_minimo ? 'stock-bajo' : ''}">${j.stock} / ${j.stock_minimo}</td>
      <td class="text-end">
        <button class="btn btn-sm btn-outline-info" data-accion="editar" data-id="${j._id}">Editar</button>
        <button class="btn btn-sm btn-outline-danger" data-accion="eliminar" data-id="${j._id}">Eliminar</button>
      </td>
    </tr>`).join('') || '<tr><td colspan="6" class="text-secondary">No hay juegos</td></tr>';

  cargarReporte();
}

// CREATE y UPDATE: el mismo formulario
$('formJuego').addEventListener('submit', async (e) => {
  e.preventDefault();

  let detalles = {};
  if ($('detalles').value.trim()) {
    try { detalles = JSON.parse($('detalles').value); }
    catch { return mostrarMensaje('Los detalles deben estar en formato JSON', 'danger'); }
  }

  const datos = {
    nombre: $('nombre').value,
    categoria: $('categoria').value,
    plataformas: [...document.querySelectorAll('#plataformas input:checked')].map(c => c.value),
    precio: Number($('precio').value),
    stock: Number($('stock').value),
    stock_minimo: Number($('stock_minimo').value),
    imagen: $('imagen').value.trim(),
    detalles
  };

  const id = $('id').value;
  const res = await api(id ? `${API}/${id}` : API, {
    method: id ? 'PUT' : 'POST',
    body: JSON.stringify(datos)
  });
  const r = await res.json();
  if (!res.ok) return mostrarMensaje(r.error, 'danger');

  mostrarMensaje(id ? 'Juego actualizado' : 'Juego agregado');
  limpiarFormulario();
  cargarJuegos();
});

// Botones Editar y Eliminar de la tabla
$('tablaJuegos').addEventListener('click', async (e) => {
  const boton = e.target.closest('button');
  if (!boton) return;
  const juego = juegosActuales.find(j => j._id === boton.dataset.id);
  if (!juego) return;

  // UPDATE: llena el formulario con los datos del juego
  if (boton.dataset.accion === 'editar') {
    $('tituloForm').textContent = 'Editar videojuego';
    $('id').value = juego._id;
    $('nombre').value = juego.nombre;
    $('categoria').value = juego.categoria;
    document.querySelectorAll('#plataformas input').forEach(c => {
      c.checked = juego.plataformas.includes(c.value);
    });
    $('precio').value = juego.precio;
    $('stock').value = juego.stock;
    $('stock_minimo').value = juego.stock_minimo;
    $('imagen').value = juego.imagen || '';
    $('detalles').value = Object.keys(juego.detalles || {}).length ? JSON.stringify(juego.detalles, null, 2) : '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // DELETE: pide confirmación y elimina
  if (boton.dataset.accion === 'eliminar') {
    if (!confirm(`¿Seguro que quieres eliminar "${juego.nombre}"?`)) return;
    const res = await api(`${API}/${juego._id}`, { method: 'DELETE' });
    const r = await res.json();
    if (!res.ok) return mostrarMensaje(r.error, 'danger');
    mostrarMensaje(r.mensaje);
    cargarJuegos();
  }
});

function limpiarFormulario() {
  $('formJuego').reset();
  $('id').value = '';
  $('tituloForm').textContent = 'Agregar videojuego';
}
$('btnCancelar').addEventListener('click', limpiarFormulario);

// Reporte con agregación (juegos y stock por plataforma)
async function cargarReporte() {
  const res = await api('/api/reportes/plataformas');
  const datos = await res.json();
  $('reporte').innerHTML = datos.map(d => `
    <div class="kpi">
      <strong>${escapar(d._id)}</strong>
      ${d.juegos} ${d.juegos === 1 ? 'juego' : 'juegos'} · ${d.stock_total} en stock
    </div>
  `).join('');
}

// Los filtros recargan la tabla al cambiar
$('buscar').addEventListener('input', cargarJuegos);
$('filtroPlataforma').addEventListener('change', cargarJuegos);
$('stockBajo').addEventListener('change', cargarJuegos);

// Al abrir la página: si ya hay sesión entra directo, si no muestra el login
if (leerToken()) mostrarPanel();
else mostrarLogin();