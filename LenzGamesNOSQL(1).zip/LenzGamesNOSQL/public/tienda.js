const $ = (id) => document.getElementById(id);
let juegos = [];            // todos los juegos de la tienda
let categoriaActiva = '';

// Evita que un texto con < > rompa la página
function escapar(texto) {
  const div = document.createElement('div');
  div.textContent = texto ?? '';
  return div.innerHTML;
}

// Formato de pesos chilenos: 32000 → $32.000
const pesos = (n) => '$' + Number(n).toLocaleString('es-CL');

// Ícono que se usa cuando el juego no tiene imagen
const ICONOS = { Aventura: '🗺️', Deportes: '⚽', Carreras: '🏎️', Acción: '💥', Estrategia: '♟️' };

// Portada: muestra la imagen del juego, o el ícono si no tiene
function portada(j, clase = '', extra = '') {
  const fondo = j.imagen
    ? `<img src="${escapar(j.imagen)}" alt="${escapar(j.nombre)}" loading="lazy">`
    : `<span class="cover-icon">${ICONOS[j.categoria] || '🎮'}</span>`;
  return `<div class="cover cover-${escapar(j.categoria)} ${j.imagen ? 'con-imagen' : ''} ${clase}">${fondo}${extra}</div>`;
}

// Estado del stock para mostrar en la tarjeta
function estadoStock(j) {
  if (j.stock === 0) return { texto: 'Agotado', clase: 'agotado' };
  if (j.stock < j.stock_minimo) return { texto: '¡Últimas unidades!', clase: 'ultimas' };
  return { texto: 'Disponible', clase: 'disponible' };
}

// ¿El juego bajó de precio? (el último precio guardado era mayor)
function precioAnterior(j) {
  const ultimo = j.historial_precio?.at(-1);
  return ultimo && ultimo.precio > j.precio ? ultimo.precio : null;
}

// Convierte "detalles" (puede tener cualquier forma) en texto legible
function valorLegible(v) {
  if (Array.isArray(v)) return v.join(', ');
  if (typeof v === 'boolean') return v ? 'Sí' : 'No';
  if (v && typeof v === 'object') return Object.entries(v).map(([k, x]) => `${k}: ${valorLegible(x)}`).join(' · ');
  return v;
}
const etiqueta = (k) => k.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());

// Aviso flotante por 2,5 segundos
function avisar(texto) {
  const a = $('aviso');
  a.textContent = texto;
  a.classList.remove('d-none');
  clearTimeout(avisar.t);
  avisar.t = setTimeout(() => a.classList.add('d-none'), 2500);
}

// ================== CATÁLOGO ==================

// Trae todos los juegos (los filtros se aplican en el navegador)
async function cargarJuegos() {
  const res = await fetch('/api/videojuegos');
  juegos = await res.json();
  mostrarJuegos();
}

function mostrarJuegos() {
  const texto = $('buscar').value.trim().toLowerCase();
  const plataforma = $('filtroPlataforma').value;
  const lista = juegos.filter(j =>
    (!texto || j.nombre.toLowerCase().includes(texto)) &&
    (!plataforma || j.plataformas.includes(plataforma)) &&
    (!categoriaActiva || j.categoria === categoriaActiva)
  );
  $('contador').textContent = `${lista.length} ${lista.length === 1 ? 'juego' : 'juegos'}`;

  $('catalogo').innerHTML = lista.map(j => {
    const est = estadoStock(j);
    return `
      <div class="col-sm-6 col-lg-4 col-xl-3">
        <article class="game-card" data-id="${j._id}">
          ${portada(j, '', `
            <span class="cover-cat">${escapar(j.categoria)}</span>
            ${precioAnterior(j) ? '<span class="cover-oferta">Oferta</span>' : ''}`)}
          <div class="p-3 d-flex flex-column flex-grow-1">
            <h6 class="game-title">${escapar(j.nombre)}</h6>
            <div class="mb-2">${j.plataformas.map(p => `<span class="badge badge-plat">${escapar(p)}</span>`).join('')}</div>
            <div class="d-flex justify-content-between align-items-end mt-auto mb-2">
              <span class="precio">${pesos(j.precio)}</span>
              <span class="estado ${est.clase}">${est.texto}</span>
            </div>
            <button class="btn btn-sm btn-info w-100" data-agregar="${j._id}" ${j.stock === 0 ? 'disabled' : ''}>
              ${j.stock === 0 ? 'Sin stock' : 'Agregar al carrito'}
            </button>
          </div>
        </article>
      </div>`;
  }).join('') || '<p class="text-secondary">No encontramos juegos con esos filtros.</p>';
}

// Clic en una tarjeta: agrega al carrito o abre el detalle
$('catalogo').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-agregar]');
  if (btn) return agregarAlCarrito(btn.dataset.agregar);

  const card = e.target.closest('.game-card');
  if (card) abrirDetalle(card.dataset.id);
});

function abrirDetalle(id) {
  const j = juegos.find(x => x._id === id);
  const est = estadoStock(j);
  const detalles = Object.entries(j.detalles || {});
  const antes = precioAnterior(j);

  $('modalTitulo').textContent = j.nombre;
  $('modalCuerpo').innerHTML = `
    ${portada(j, 'cover-grande mb-3')}
    <p class="mb-1"><span class="text-secondary">Categoría:</span> ${escapar(j.categoria)}</p>
    <p class="mb-1"><span class="text-secondary">Plataformas:</span> ${j.plataformas.map(escapar).join(', ')}</p>
    <p class="mb-3"><span class="estado ${est.clase}">${est.texto}</span> <span class="text-secondary small">(${j.stock} en stock)</span></p>
    ${detalles.length ? `
      <h6 class="seccion">Detalles</h6>
      <ul class="list-unstyled small">
        ${detalles.map(([k, v]) => `<li><span class="text-secondary">${escapar(etiqueta(k))}:</span> ${escapar(String(valorLegible(v)))}</li>`).join('')}
      </ul>` : ''}
    <div class="d-flex align-items-center gap-2 mt-3">
      <span class="precio fs-3">${pesos(j.precio)}</span>
      ${antes ? `<span class="text-secondary text-decoration-line-through">${pesos(antes)}</span>` : ''}
      <button class="btn btn-info ms-auto" id="btnAgregarDetalle" ${j.stock === 0 ? 'disabled' : ''}>
        ${j.stock === 0 ? 'Sin stock' : 'Agregar al carrito'}
      </button>
    </div>`;
  $('btnAgregarDetalle').onclick = () => agregarAlCarrito(j._id);
  bootstrap.Modal.getOrCreateInstance($('modalJuego')).show();
}

// ================== CARRITO (guardado en MongoDB) ==================
// El navegador solo recuerda el id del carrito; los productos están en la colección "carritos"
let carrito = null;

async function obtenerCarrito() {
  let id = null;
  try { id = localStorage.getItem('lenz_carrito_id'); } catch {}
  if (id) {
    const res = await fetch(`/api/carritos/${id}`);
    if (res.ok) {
      carrito = await res.json();
      return mostrarCarrito();
    }
  }
  // No había carrito (o expiró): crea uno nuevo
  const res = await fetch('/api/carritos', { method: 'POST' });
  carrito = await res.json();
  try { localStorage.setItem('lenz_carrito_id', carrito._id); } catch {}
  mostrarCarrito();
}

const cantidadEnCarrito = (id) => carrito?.items.find(it => it.videojuego._id === id)?.cantidad || 0;

// Cambia la cantidad de un juego en el carrito (0 = quitarlo)
async function fijarCantidad(juegoId, cantidad, reintento = true) {
  const res = await fetch(`/api/carritos/${carrito._id}/items/${juegoId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cantidad })
  });
  const r = await res.json();
  if (res.status === 404 && r.error === 'Carrito no encontrado' && reintento) {
    await obtenerCarrito();   // el carrito expiró: crea otro y reintenta
    return fijarCantidad(juegoId, cantidad, false);
  }
  if (!res.ok) { avisar(r.error); return false; }
  carrito = r;
  mostrarCarrito();
  return true;
}

async function agregarAlCarrito(id) {
  const juego = juegos.find(j => j._id === id);
  if (await fijarCantidad(id, cantidadEnCarrito(id) + 1)) avisar(`"${juego.nombre}" agregado al carrito`);
}

// Lista del carrito con los datos actuales de cada juego
const itemsDelCarrito = () => (carrito?.items || []).map(it => ({ juego: it.videojuego, cantidad: it.cantidad }));

function mostrarCarrito() {
  const items = itemsDelCarrito();
  const unidades = items.reduce((s, it) => s + it.cantidad, 0);
  const total = items.reduce((s, it) => s + it.juego.precio * it.cantidad, 0);

  $('contadorCarrito').textContent = unidades;
  $('contadorCarrito').classList.toggle('d-none', unidades === 0);
  $('totalCarrito').textContent = pesos(total);
  $('btnComprar').disabled = items.length === 0;

  $('itemsCarrito').innerHTML = items.map(({ juego: j, cantidad }) => `
    <div class="item-carrito">
      ${j.imagen ? `<img src="${escapar(j.imagen)}" alt="">` : `<div class="item-icono">${ICONOS[j.categoria] || '🎮'}</div>`}
      <div class="flex-grow-1">
        <div class="fw-semibold">${escapar(j.nombre)}</div>
        <div class="text-secondary small">${pesos(j.precio)} c/u</div>
        <div class="d-flex align-items-center gap-2 mt-1">
          <button class="btn btn-sm btn-outline-secondary" data-cambio="-1" data-id="${j._id}">−</button>
          <span>${cantidad}</span>
          <button class="btn btn-sm btn-outline-secondary" data-cambio="1" data-id="${j._id}">+</button>
          <button class="btn btn-sm btn-link text-danger ms-auto" data-quitar="${j._id}">Quitar</button>
        </div>
      </div>
    </div>`).join('') || '<p class="text-secondary">Tu carrito está vacío.</p>';
}

$('itemsCarrito').addEventListener('click', (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  if (b.dataset.cambio) {
    const id = b.dataset.id;
    fijarCantidad(id, Math.max(0, cantidadEnCarrito(id) + Number(b.dataset.cambio)));
  }
  if (b.dataset.quitar) fijarCantidad(b.dataset.quitar, 0);
});

// ================== CHECKOUT ==================

$('btnComprar').addEventListener('click', () => {
  const items = itemsDelCarrito();
  const total = items.reduce((s, it) => s + it.juego.precio * it.cantidad, 0);
  $('resumenCheckout').innerHTML = items.map(({ juego, cantidad }) =>
    `<div class="d-flex justify-content-between small"><span>${cantidad} × ${escapar(juego.nombre)}</span><span>${pesos(juego.precio * cantidad)}</span></div>`
  ).join('') + `<div class="d-flex justify-content-between fw-bold border-top mt-2 pt-2"><span>Total</span><span>${pesos(total)}</span></div>`;

  $('formCheckout').classList.remove('d-none');
  $('pedidoListo').classList.add('d-none');
  $('errorCheckout').textContent = '';
  bootstrap.Offcanvas.getOrCreateInstance($('carrito')).hide();
  bootstrap.Modal.getOrCreateInstance($('modalCheckout')).show();
});

$('formCheckout').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('btnConfirmar').disabled = true;
  $('errorCheckout').textContent = '';

  const datos = {
    cliente: {
      nombre: $('cNombre').value,
      email: $('cEmail').value,
      telefono: $('cTelefono').value,
      direccion: $('cDireccion').value
    },
    carritoId: carrito._id
  };

  try {
    const res = await fetch('/api/pedidos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    });
    const r = await res.json();
    if (!res.ok) {
      $('errorCheckout').textContent = r.error;
      cargarJuegos();     // actualiza el stock por si cambió
      obtenerCarrito();
      return;
    }
    // Pedido creado: vacía el carrito y muestra el código
    await obtenerCarrito();   // el servidor borró el carrito usado: se crea uno nuevo
    $('formCheckout').reset();
    $('codigoPedido').textContent = r.codigo;
    $('formCheckout').classList.add('d-none');
    $('pedidoListo').classList.remove('d-none');
    cargarJuegos();
  } catch {
    $('errorCheckout').textContent = 'No se pudo conectar con el servidor';
  } finally {
    $('btnConfirmar').disabled = false;
  }
});

// ================== SEGUIMIENTO ==================

$('formSeguimiento').addEventListener('submit', async (e) => {
  e.preventDefault();
  const params = new URLSearchParams({ codigo: $('sCodigo').value, email: $('sEmail').value });
  const res = await fetch(`/api/seguimiento?${params}`);
  const r = await res.json();
  if (!res.ok) {
    $('resultadoSeguimiento').innerHTML = `<p class="text-danger">${escapar(r.error)}</p>`;
    return;
  }
  $('resultadoSeguimiento').innerHTML = `
    <div class="resumen">
      <div class="d-flex justify-content-between mb-2">
        <strong>${escapar(r.codigo)}</strong>
        <span class="badge estado-${escapar(r.estado)}">${escapar(r.estado)}</span>
      </div>
      <div class="text-secondary small mb-2">${new Date(r.createdAt).toLocaleString('es-CL')}</div>
      ${r.items.map(it => `<div class="d-flex justify-content-between small"><span>${it.cantidad} × ${escapar(it.nombre)}</span><span>${pesos(it.precio * it.cantidad)}</span></div>`).join('')}
      <div class="d-flex justify-content-between fw-bold border-top mt-2 pt-2"><span>Total</span><span>${pesos(r.total)}</span></div>
    </div>`;
});

// ================== FILTROS ==================

$('categorias').addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  categoriaActiva = btn.dataset.cat;
  document.querySelectorAll('#categorias button').forEach(b => b.classList.toggle('activa', b === btn));
  mostrarJuegos();
});
$('buscar').addEventListener('input', mostrarJuegos);
$('filtroPlataforma').addEventListener('change', mostrarJuegos);

// Al abrir la página, carga los juegos y el carrito
cargarJuegos();
obtenerCarrito();