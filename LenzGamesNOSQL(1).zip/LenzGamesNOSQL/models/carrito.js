const mongoose = require('mongoose');

// Subdocumento embebido: un juego dentro del carrito
const itemSchema = new mongoose.Schema({
  videojuego: { type: mongoose.Schema.Types.ObjectId, ref: 'Videojuego', required: true },
  cantidad: {
    type: Number, required: true,
    min: [1, 'La cantidad mínima es 1'],
    max: [10, 'Máximo 10 unidades por juego']
  }
}, { _id: false });

const carritoSchema = new mongoose.Schema({
  items: { type: [itemSchema], default: [] }
}, { timestamps: true, collection: 'carritos' });

// Índice TTL: MongoDB borra solo los carritos sin cambios en 7 días
carritoSchema.index({ updatedAt: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 7 });

module.exports = mongoose.model('Carrito', carritoSchema);