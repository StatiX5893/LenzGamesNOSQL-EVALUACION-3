const mongoose = require('mongoose');

const CATEGORIAS = ['Aventura', 'Deportes', 'Carreras', 'Acción', 'Estrategia'];
const PLATAFORMAS = ['PC', 'PS5', 'Xbox Series', 'Switch'];

// Subdocumento embebido: cada cambio de precio
const historialSchema = new mongoose.Schema({
  precio: { type: Number, required: true },
  fecha:  { type: Date, default: Date.now }
}, { _id: false });

const videojuegoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: [true, 'El nombre es obligatorio'],
    trim: true,
    unique: true,
    minlength: [2, 'El nombre debe tener al menos 2 caracteres'],
    maxlength: [60, 'El nombre no puede superar 60 caracteres']
  },
  categoria: {
    type: String,
    required: [true, 'La categoría es obligatoria'],
    enum: { values: CATEGORIAS, message: 'Categoría no válida. Usa: ' + CATEGORIAS.join(', ') }
  },
  plataformas: {
    type: [{ type: String, enum: { values: PLATAFORMAS, message: 'Plataforma "{VALUE}" no válida' } }],
    validate: { validator: (v) => v.length > 0, message: 'Debe tener al menos una plataforma' }
  },
  precio: {
    type: Number,
    required: [true, 'El precio es obligatorio'],
    min: [1, 'El precio debe ser mayor a 0'],
    max: [500000, 'El precio no puede superar $500.000']
  },
  stock: {
    type: Number,
    default: 0,
    min: [0, 'El stock no puede ser negativo'],
    validate: { validator: Number.isInteger, message: 'El stock debe ser un número entero' }
  },
  stock_minimo: {
    type: Number,
    default: 5,
    min: [0, 'El stock mínimo no puede ser negativo'],
    validate: { validator: Number.isInteger, message: 'El stock mínimo debe ser un número entero' }
  },
  imagen: { type: String, trim: true, default: '' },   // ruta o URL de la portada
  detalles: { type: mongoose.Schema.Types.Mixed, default: {} },
  historial_precio: { type: [historialSchema], default: [] }
}, { timestamps: true, collection: 'videojuegos' });

module.exports = mongoose.model('Videojuego', videojuegoSchema);
module.exports.CATEGORIAS = CATEGORIAS;
module.exports.PLATAFORMAS = PLATAFORMAS;