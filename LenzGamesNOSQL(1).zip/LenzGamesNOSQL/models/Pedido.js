const mongoose = require('mongoose');

const ESTADOS = ['Pendiente', 'Pagado', 'Enviado', 'Entregado', 'Cancelado'];

// Subdocumento embebido: cada producto del pedido.
// Se guarda una copia del nombre y precio para que el pedido no cambie
// si después se edita o elimina el juego.
const itemSchema = new mongoose.Schema({
  videojuego: { type: mongoose.Schema.Types.ObjectId, ref: 'Videojuego', required: true },
  nombre:     { type: String, required: true },
  imagen:     { type: String, default: '' },
  precio:     { type: Number, required: true },
  cantidad:   { type: Number, required: true, min: 1 }
}, { _id: false });

const pedidoSchema = new mongoose.Schema({
  codigo: { type: String, required: true, unique: true },
  cliente: {
    nombre: {
      type: String, trim: true,
      required: [true, 'El nombre es obligatorio'],
      maxlength: [80, 'El nombre es demasiado largo']
    },
    email: {
      type: String, trim: true, lowercase: true,
      required: [true, 'El correo es obligatorio'],
      match: [/^\S+@\S+\.\S+$/, 'El correo no es válido']
    },
    telefono: { type: String, trim: true, maxlength: [20, 'El teléfono es demasiado largo'] },
    direccion: {
      type: String, trim: true,
      required: [true, 'La dirección es obligatoria'],
      maxlength: [150, 'La dirección es demasiado larga']
    }
  },
  items: {
    type: [itemSchema],
    validate: { validator: (v) => v.length > 0, message: 'El pedido no tiene productos' }
  },
  total:  { type: Number, required: true, min: 0 },
  estado: { type: String, enum: ESTADOS, default: 'Pendiente' }
}, { timestamps: true, collection: 'pedidos' });

module.exports = mongoose.model('Pedido', pedidoSchema);
module.exports.ESTADOS = ESTADOS;