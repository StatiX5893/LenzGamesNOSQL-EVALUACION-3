require('dotenv').config();
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const mongoose = require('mongoose');
const Videojuego = require('./models/Videojuego');
const Pedido = require('./models/Pedido');
const Carrito = require('./models/Carrito');

const app = express();
app.use(express.json());            // permite recibir datos en formato JSON
app.use(express.static(path.join(__dirname, 'public')));  // muestra la página de la carpeta public

// El panel de administración se abre en /panel
app.get('/panel', (req, res) => res.sendFile(path.join(__dirname, 'public', 'panel.html')));

// Conexión a MongoDB local
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Conectado a MongoDB'))
  .catch(err => console.error('Error al conectar a MongoDB:', err.message));

// Convierte los errores de MongoDB/Mongoose en mensajes claros
function mensajeError(err) {
  if (err.name === 'ValidationError') {
    return Object.values(err.errors).map(e => e.message).join(' · ');
  }
  if (err.code === 11000) return 'Ya existe un juego con ese nombre';
  if (err.name === 'CastError') return 'Id no válido';
  return err.message;
}

// ================== LOGIN DEL ADMINISTRADOR ==================
// Las sesiones se guardan en memoria: al reiniciar el servidor hay que volver a entrar
const sesiones = new Set();

// Middleware: deja pasar solo si viene un token válido
function soloAdmin(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!sesiones.has(token)) return res.status(401).json({ error: 'Debes iniciar sesión' });
  req.token = token;
  next();
}

app.post('/api/login', (req, res) => {
  if (!process.env.ADMIN_PASSWORD) {
    return res.status(500).json({ error: 'Falta ADMIN_PASSWORD en el archivo .env' });
  }
  if (req.body.password !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Contraseña incorrecta' });
  }
  const token = crypto.randomUUID();
  sesiones.add(token);
  res.json({ token });
});

app.post('/api/logout', soloAdmin, (req, res) => {
  sesiones.delete(req.token);
  res.json({ mensaje: 'Sesión cerrada' });
});

// ================== VIDEOJUEGOS ==================

// READ (público): listar juegos, con filtros opcionales
app.get('/api/videojuegos', async (req, res) => {
  try {
    const { buscar, plataforma, stockBajo } = req.query;
    const filtro = {};

    if (buscar) {
      const seguro = buscar.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      filtro.nombre = { $regex: seguro, $options: 'i' };
    }
    if (plataforma) filtro.plataformas = plataforma;
    if (stockBajo === 'true') filtro.$expr = { $lt: ['$stock', '$stock_minimo'] };

    const juegos = await Videojuego.find(filtro).sort({ nombre: 1 });
    res.json(juegos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// READ (público): un solo juego por su id
app.get('/api/videojuegos/:id', async (req, res) => {
  try {
    const juego = await Videojuego.findById(req.params.id);
    if (!juego) return res.status(404).json({ error: 'Juego no encontrado' });
    res.json(juego);
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// CREATE (admin): agregar un juego
app.post('/api/videojuegos', soloAdmin, async (req, res) => {
  try {
    const juego = await Videojuego.create(req.body);
    res.status(201).json(juego);
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// UPDATE (admin): si cambia el precio, guarda el anterior en el historial
app.put('/api/videojuegos/:id', soloAdmin, async (req, res) => {
  try {
    const juego = await Videojuego.findById(req.params.id);
    if (!juego) return res.status(404).json({ error: 'Juego no encontrado' });

    const { precio, _id, historial_precio, ...resto } = req.body;
    if (precio !== undefined && Number(precio) !== juego.precio) {
      juego.historial_precio.push({ precio: juego.precio, fecha: new Date() });
      juego.precio = precio;
    }
    Object.assign(juego, resto);
    await juego.save();
    res.json(juego);
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// DELETE (admin): eliminar un juego
app.delete('/api/videojuegos/:id', soloAdmin, async (req, res) => {
  try {
    const juego = await Videojuego.findByIdAndDelete(req.params.id);
    if (!juego) return res.status(404).json({ error: 'Juego no encontrado' });
    res.json({ mensaje: `"${juego.nombre}" eliminado` });
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// ================== CARRITO (guardado en MongoDB) ==================

// Devuelve el carrito con los datos de cada juego (populate),
// sin los juegos que ya fueron eliminados del catálogo
async function verCarrito(id) {
  const carrito = await Carrito.findById(id).populate('items.videojuego').lean();
  if (carrito) carrito.items = carrito.items.filter(it => it.videojuego);
  return carrito;
}

// CREATE: carrito nuevo y vacío
app.post('/api/carritos', async (req, res) => {
  try {
    const carrito = await Carrito.create({ items: [] });
    res.status(201).json(carrito);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// READ: ver un carrito
app.get('/api/carritos/:id', async (req, res) => {
  try {
    const carrito = await verCarrito(req.params.id);
    if (!carrito) return res.status(404).json({ error: 'Carrito no encontrado' });
    res.json(carrito);
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// UPDATE: fija la cantidad de un juego en el carrito (0 = quitarlo)
app.put('/api/carritos/:id/items/:juegoId', async (req, res) => {
  try {
    const cantidad = Number(req.body.cantidad);
    if (!Number.isInteger(cantidad) || cantidad < 0 || cantidad > 10) {
      return res.status(400).json({ error: 'Cantidad no válida (máximo 10 por juego)' });
    }

    const carrito = await Carrito.findById(req.params.id);
    if (!carrito) return res.status(404).json({ error: 'Carrito no encontrado' });

    const juego = await Videojuego.findById(req.params.juegoId);
    if (!juego) return res.status(404).json({ error: 'Juego no encontrado' });
    if (cantidad > juego.stock) {
      return res.status(400).json({ error: `Solo quedan ${juego.stock} unidades de "${juego.nombre}"` });
    }

    const item = carrito.items.find(it => it.videojuego.equals(juego._id));
    if (cantidad === 0) carrito.items = carrito.items.filter(it => !it.videojuego.equals(juego._id));
    else if (item) item.cantidad = cantidad;
    else carrito.items.push({ videojuego: juego._id, cantidad });

    await carrito.save();
    res.json(await verCarrito(carrito._id));
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// ================== PEDIDOS ==================

// Código corto para el cliente, ej: LZ-4F9A2C
const nuevoCodigo = () => 'LZ-' + crypto.randomBytes(3).toString('hex').toUpperCase();

// CREATE (público): convierte el carrito guardado en MongoDB en un pedido.
// El precio se toma de la base de datos, no del navegador.
app.post('/api/pedidos', async (req, res) => {
  const descontados = [];   // para devolver el stock si algo falla
  try {
    const { carritoId, cliente } = req.body;
    const carrito = await Carrito.findById(carritoId);
    if (!carrito || carrito.items.length === 0) {
      return res.status(400).json({ error: 'El carrito está vacío' });
    }

    // Junta las cantidades por juego
    const cantidades = {};
    for (const it of carrito.items) {
      const id = it.videojuego.toString();
      cantidades[id] = (cantidades[id] || 0) + it.cantidad;
    }

    // Descuenta el stock solo si alcanza (operación atómica de MongoDB)
    const lineas = [];
    for (const [id, cantidad] of Object.entries(cantidades)) {
      const juego = await Videojuego.findOneAndUpdate(
        { _id: id, stock: { $gte: cantidad } },
        { $inc: { stock: -cantidad } },
        { new: true }
      );
      if (!juego) {
        const existe = await Videojuego.findById(id);
        if (!existe) continue;   // el juego fue eliminado del catálogo: se omite
        throw new Error(`No hay stock suficiente de "${existe.nombre}" (quedan ${existe.stock})`);
      }
      descontados.push({ id, cantidad });
      lineas.push({ videojuego: juego._id, nombre: juego.nombre, imagen: juego.imagen, precio: juego.precio, cantidad });
    }

    if (lineas.length === 0) throw new Error('Los juegos del carrito ya no están disponibles');

    const total = lineas.reduce((suma, l) => suma + l.precio * l.cantidad, 0);
    const pedido = await Pedido.create({ codigo: nuevoCodigo(), cliente, items: lineas, total });
    await Carrito.findByIdAndDelete(carrito._id);   // el carrito ya se convirtió en pedido
    res.status(201).json(pedido);
  } catch (err) {
    // Si algo falló, devuelve el stock que alcanzó a descontar
    for (const d of descontados) {
      await Videojuego.updateOne({ _id: d.id }, { $inc: { stock: d.cantidad } });
    }
    res.status(400).json({ error: mensajeError(err) });
  }
});

// READ (público): el cliente revisa su pedido con el código y su correo
app.get('/api/seguimiento', async (req, res) => {
  try {
    const { codigo, email } = req.query;
    const pedido = await Pedido.findOne({
      codigo: String(codigo || '').trim().toUpperCase(),
      'cliente.email': String(email || '').trim().toLowerCase()
    });
    if (!pedido) return res.status(404).json({ error: 'No encontramos un pedido con esos datos' });
    res.json({ codigo: pedido.codigo, estado: pedido.estado, total: pedido.total, items: pedido.items, createdAt: pedido.createdAt });
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// READ (admin): todos los pedidos, el más nuevo primero
app.get('/api/pedidos', soloAdmin, async (req, res) => {
  try {
    const filtro = {};
    if (req.query.estado) filtro.estado = req.query.estado;
    const pedidos = await Pedido.find(filtro).sort({ createdAt: -1 });
    res.json(pedidos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE (admin): cambiar el estado. Si se cancela, el stock vuelve.
app.patch('/api/pedidos/:id/estado', soloAdmin, async (req, res) => {
  try {
    const { estado } = req.body;
    if (!Pedido.ESTADOS.includes(estado)) return res.status(400).json({ error: 'Estado no válido' });

    const pedido = await Pedido.findById(req.params.id);
    if (!pedido) return res.status(404).json({ error: 'Pedido no encontrado' });
    if (pedido.estado === 'Cancelado') {
      return res.status(400).json({ error: 'Un pedido cancelado ya no se puede modificar' });
    }

    if (estado === 'Cancelado') {
      for (const it of pedido.items) {
        await Videojuego.updateOne({ _id: it.videojuego }, { $inc: { stock: it.cantidad } });
      }
    }
    pedido.estado = estado;
    await pedido.save();
    res.json(pedido);
  } catch (err) {
    res.status(400).json({ error: mensajeError(err) });
  }
});

// ================== REPORTES (admin, con agregación) ==================

// Juegos y stock total por plataforma
app.get('/api/reportes/plataformas', soloAdmin, async (req, res) => {
  try {
    const datos = await Videojuego.aggregate([
      { $unwind: '$plataformas' },
      { $group: { _id: '$plataformas', juegos: { $sum: 1 }, stock_total: { $sum: '$stock' } } },
      { $sort: { _id: 1 } }
    ]);
    res.json(datos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Ventas: total vendido, pedidos por estado y juegos más vendidos
app.get('/api/reportes/ventas', soloAdmin, async (req, res) => {
  try {
    const [resumen] = await Pedido.aggregate([
      { $match: { estado: { $ne: 'Cancelado' } } },
      { $group: { _id: null, ventas: { $sum: '$total' }, pedidos: { $sum: 1 } } }
    ]);
    const porEstado = await Pedido.aggregate([
      { $group: { _id: '$estado', cantidad: { $sum: 1 } } }
    ]);
    const masVendidos = await Pedido.aggregate([
      { $match: { estado: { $ne: 'Cancelado' } } },
      { $unwind: '$items' },
      { $group: { _id: '$items.nombre', unidades: { $sum: '$items.cantidad' } } },
      { $sort: { unidades: -1 } },
      { $limit: 3 }
    ]);
    res.json({
      ventas: resumen?.ventas || 0,
      pedidos: resumen?.pedidos || 0,
      porEstado: Object.fromEntries(porEstado.map(e => [e._id, e.cantidad])),
      masVendidos
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor en http://localhost:${PORT}`));