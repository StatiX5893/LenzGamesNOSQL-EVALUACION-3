require('dotenv').config();
const mongoose = require('mongoose');
const Videojuego = require('./models/Videojuego');
const Carrito = require('./models/Carrito');

const juegos = [
  {
    nombre: 'Isla Perdida', categoria: 'Aventura', plataformas: ['PC', 'PS5'],
    imagen: '/img/isla-perdida.jpg',
    precio: 32000, stock: 2, stock_minimo: 5,
    detalles: { requisitos_pc: { ram: '8 GB', gpu: 'GTX 1060' }, clasificacion: 'T' },
    historial_precio: [{ precio: 30000, fecha: new Date('2026-10-01') }]
  },
  {
    nombre: 'Mundo Lunar', categoria: 'Aventura', plataformas: ['Switch'],
    imagen: '/img/mundo-lunar.jpg',
    precio: 25000, stock: 8, stock_minimo: 5,
    detalles: { edicion: 'Estándar', multijugador: false }
  },
  {
    nombre: 'Futbol Total', categoria: 'Deportes', plataformas: ['PS5', 'Xbox Series'],
    imagen: '/img/futbol-total.jpg',
    precio: 45000, stock: 4, stock_minimo: 6,
    detalles: { modos: ['Carrera', 'Online'], licencias_oficiales: true }
  },
  {
    nombre: 'Carrera Urbana', categoria: 'Carreras', plataformas: ['PC', 'Xbox Series'],
    imagen: '/img/carrera-urbana.jpg',
    precio: 35000, stock: 10, stock_minimo: 4,
    detalles: { dlc: ['Pack Nocturno'] }
  },
  {
    nombre: 'Velocidad Extrema', categoria: 'Carreras', plataformas: ['PS5'],
    imagen: '/img/velocidad-extrema.jpg',
    precio: 28000, stock: 3, stock_minimo: 5,
    detalles: { volante_compatible: true }
  }
];

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    await Videojuego.deleteMany({});          // limpia la colección
    await Carrito.deleteMany({});             // los carritos apuntaban a los juegos anteriores
    await Videojuego.insertMany(juegos);      // inserta los 5 juegos
    console.log(`${juegos.length} juegos cargados en lenz_games.videojuegos`);
  } catch (err) {
    console.error('Error:', err.message);
  } finally {
    await mongoose.disconnect();
  }
})();